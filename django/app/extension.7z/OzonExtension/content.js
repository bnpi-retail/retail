const dataAd = {
    number: null,
    search: null,
    href: window.location.href,
    seller: null,
    sku: null,
    price_with_card: null,
    price: null,
    price_without_sale: null,
};

let active = parseInt(localStorage.getItem('active'), 10) || 0;
active += 1;
localStorage.setItem('active', active);
active_progress = active * 10
localStorage.setItem('progress', active_progress.toString());
chrome.storage.local.set({ 'progress': active_progress })

async function waitForElementByXPath(fullXPath, maxAttempts = 20, interval = 200) {
    let attempts = 0;

    for (;;) {
        const result = document.evaluate(
            fullXPath,
            document,
            null,
            XPathResult.FIRST_ORDERED_NODE_TYPE,
            null
        );

        const element = result.singleNodeValue;

        if (element) {
            console.log(`Found element with full XPath '${fullXPath}'.`);
            return element;
        }

        attempts++;

        if (attempts >= maxAttempts) {
            console.log(`Maximum attempts reached with full XPath '${fullXPath}'. Element not found.`);
            return null;
        }

        await new Promise(resolve => setTimeout(resolve, interval));
    }
}

async function main() {
    dataAd.number = active

    const inputElement = document.querySelector('input[name="text"]');
    if (inputElement) {
        dataAd['search'] = inputElement.value;
        console.log(inputElement.value);
    }
    const elementSku = await waitForElementByXPath("/html/body/div[1]/div/div[1]/div[4]/div[2]/div/div/div[2]/span");
    if (elementSku) {
        dataAd['sku'] = elementSku.textContent.replace("Код товара: ", "").trim()
    }
    const elementPriceWithCard = await waitForElementByXPath("/html/body/div[1]/div/div[1]/div[4]/div[3]/div[2]/div[2]/div[2]/div/div[1]/div/div/div[1]/div[1]/button/span/div/div[1]/div/div/span");
    if (elementPriceWithCard) {
        dataAd['price_with_card'] = elementPriceWithCard.textContent.replace(/\s/g, '').replace('₽', '').trim()
    }
    const elementPrice = await waitForElementByXPath("/html/body/div[1]/div/div[1]/div[4]/div[3]/div[2]/div[2]/div[2]/div/div[1]/div/div/div[1]/div[2]/div/div[1]/span[1]");
    if (elementPrice) {
        dataAd['price'] = elementPrice.textContent.replace(/\s/g, '').replace('₽', '').trim()
    }
    const elementPriceWithoutSale = await waitForElementByXPath("/html/body/div[1]/div/div[1]/div[4]/div[3]/div[2]/div[2]/div[2]/div/div[1]/div/div/div[1]/div[2]/div/div[1]/span[2]");
    if (elementSku) {
        dataAd['price_without_sale'] = elementPriceWithoutSale.textContent.replace(/\s/g, '').replace('₽', '').trim()
    }
    const elementSeller = await waitForElementByXPath("/html/body/div[1]/div/div[1]/div[6]/div/div[1]/div[2]/div/div/div/div[1]/div/div/div[2]/div[1]/div/a");
    if (elementSeller) {
        dataAd['seller'] = elementSeller.textContent
    }

    const storedDataString = localStorage.getItem('collectedDataArray');
    let storedData;

    try {
        storedData = JSON.parse(storedDataString) || [];
    } catch (error) {
        console.error('Ошибка при преобразовании строки в массив объектов:', error);
    }

    let lastData = storedData[storedData.length - 1];
    lastData.elements.push(dataAd);
    console.log('Final data:', dataAd);
    console.log('Last data:', lastData);
    localStorage.setItem('collectedDataArray', JSON.stringify(storedData));
}

if (active < 11) {
    main();
}
