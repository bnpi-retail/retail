if (window.location.hostname.includes('ozon')) {
  const info = document.createElement('div');
  info.classList.add('info_extension'); // Обновленный класс
  document.body.append(info);

  let isDragging = false;
  let offsetX, offsetY;

  // Загрузка предыдущих координат из localStorage
  const savedLeft = localStorage.getItem('infoLeft');
  const savedTop = localStorage.getItem('infoTop');

  if (savedLeft && savedTop) {
      info.style.left = savedLeft;
      info.style.top = savedTop;
  }

  // Обработчик нажатия мыши
  info.addEventListener('mousedown', (e) => {
      isDragging = true;
      offsetX = e.clientX - info.getBoundingClientRect().left;
      offsetY = e.clientY - info.getBoundingClientRect().top;
  });

  // Обработчик отпускания мыши
  document.addEventListener('mouseup', () => {
      isDragging = false;

      // Сохранение текущих координат в localStorage
      localStorage.setItem('infoLeft', info.style.left);
      localStorage.setItem('infoTop', info.style.top);
  });

  // Обработчик движения мыши
  document.addEventListener('mousemove', (e) => {
      if (isDragging) {
          const x = e.clientX - offsetX;
          const y = e.clientY - offsetY;

          info.style.left = `${x}px`;
          info.style.top = `${y}px`;
      }
  });

  function updateInfo() {
      const storedDataString = localStorage.getItem('collectedDataArray');
      const storedDataArray = storedDataString ? JSON.parse(storedDataString) : [];
      const requests = storedDataArray.length;
      let ads = 0;
      for (const obj of storedDataArray) {
          ads += obj.elements.length;
      }
      info.innerText = `Запросы: ${requests}, Объявления: ${ads}`;
  }

  setInterval(updateInfo, 1000);
  updateInfo();
}