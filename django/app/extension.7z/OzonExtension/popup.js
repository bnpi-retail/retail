function collectData() {
  const inputElement = document.querySelector('input[placeholder="Искать на Ozon"].tsBody500Medium');
  const searchQuery = inputElement ? inputElement.value : null;

  const allElements = document.querySelector('div.widget-search-result-container');
  const childElement = allElements.querySelector(':scope > div')
  const elements = Array.from(childElement.querySelectorAll(':scope > div')).slice(0, 10);

  function processElements(elements) {
    const links = [];
  
    elements.forEach(element => {
      const hrefElement = element.querySelector(':scope > a');
      if (hrefElement) {
        const href = 'https://www.ozon.ru' + hrefElement.getAttribute('href');
        links.push(href);
      }
    });
    return links;
  }
  
  localStorage.setItem('active', 0);
  const hrefs = processElements(elements);
  chrome.runtime.sendMessage({ action: "openTab", hrefs: hrefs });
  
  const dataToSend = {
    search: searchQuery,
    elements: []
  };

  const storedDataString = localStorage.getItem('collectedDataArray');
  const storedDataArray = storedDataString ? JSON.parse(storedDataString) : [];
  storedDataArray.push(dataToSend);
  localStorage.setItem('collectedDataArray', JSON.stringify(storedDataArray));
  console.log(storedDataArray);
}

const collectButton = document.getElementById("collectData");
collectButton.addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    function: collectData,
  });
});

function downloadCSVFile() {
  function createCSVContent() {
    const storedDataString = localStorage.getItem('collectedDataArray');
    const storedDataArray = JSON.parse(storedDataString) || [];
    const csvContent = storedDataArray.map((item) => {
      const elements = item.elements.map((element) => {
        const name = element.name;
        const number = element.number;
        const search = element.search;
        const seller = element.seller;
        const sku = element.sku;
        const price = element.price;
        const price_without_sale = element.price_without_sale;
        const href = element.href;
        const price_with_card = element.price_with_card;
        return `${number},${search},${seller},${sku},${price},${price_without_sale},${price_with_card},${href},${name}`;
      }).join('\n');
  
      return elements;
    }).join('\n');
  
    return `search,seller,sku,price,price_without_sale,href,name\n${csvContent}`;
  }
  const csvFileContent = createCSVContent();
  const blob = new Blob([csvFileContent], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = window.URL.createObjectURL(blob);
  a.download = 'data.csv';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

const downloadButton = document.getElementById("downloadData");
downloadButton.addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    function: downloadCSVFile,
  });
});


async function sendData() {
  var apiToken = localStorage.getItem('apiToken');
  try {
    const storedDataString = localStorage.getItem('collectedDataArray');
    const storedDataArray = JSON.parse(storedDataString) || [];
  
    // const response = await fetch('http://localhost:8000/take_ozon_data/', {
      const response = await fetch('https://retail-extension.bnpi.dev/take_ozon_data/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Token ${apiToken}`,
      },
      body: JSON.stringify(storedDataArray),
    });

    const responseData = await response.text();

    console.log('Код статуса:', response.status);
    console.log('Текст ответа:', responseData);
  } catch (error) {
    console.error('Ошибка запроса:', error);
  }
}

const sendButton = document.getElementById("sendData");
sendButton.addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    function: sendData,
  });
});


function clearFunc() {
  const storedDataArray = [];
  localStorage.setItem('collectedDataArray', JSON.stringify(storedDataArray));
  localStorage.setItem('active', 11);
  chrome.storage.local.set({ 'progress': 100 })
  console.log('Data is cleared!')
}

const clearButton = document.getElementById("clearData");
clearButton.addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    function: clearFunc,
  });
});


function openWindow() {
  const newWindow = window.open('', 'Добавление API ключа', 'width=600,height=400');
  
  const htmlContent = `
    <html>
    <head>
    <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f5f5f5;
      margin: 20px;
    }
  
    h1 {
      color: #333;
    }
  
    form {
      margin-top: 20px;
    }
  
    label {
      display: block;
      margin-bottom: 5px;
    }
  
    input {
      width: 100%;
      padding: 8px;
      margin-bottom: 10px;
      box-sizing: border-box;
      border-radius: 5px;
    }
  
    button {
      background-color: #0066CC;
      color: white;
      padding: 10px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
  
    button:hover {
      background-color: #005bb5;
    }
  </style>
  
    </head>
    <body>
      <h1>Добро пожаловать!</h1>
      <form id="tokenForm">
        <label for="apiToken">Введите API токен:</label>
        <input type="text" id="apiToken" name="apiToken">
        <br>
        <button type="button" id="saveToken">Сохранить</button>
      </form>
    </body>
    </html>
  `;

  newWindow.document.write(htmlContent);

  newWindow.document.getElementById('saveToken').addEventListener('click', async function() {
    const apiTokenValue = newWindow.document.getElementById('apiToken').value;

    async function checkAuthentication() {
      try {
        const response = await fetch('https://retail-extension.bnpi.dev/check_auth/', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Token ${apiTokenValue}`,
          },
        });

        if (response.status === 200) {
          console.log('Authentication successful', response.status);
          return true;
        } else if (response.status === 401) {
          console.log('Authentication failed');
          return false;
        } else {
          console.error('Unexpected response:', response.status);
          return false;
        }
      } catch (error) {
        console.error('Error during authentication check:', error);
        return false;
      }
    }

    newWindow.document.body.innerHTML = '';
    const isAuthenticated = await checkAuthentication();
    if (isAuthenticated) {
      alert('API токен успешно добавлен!');
      localStorage.setItem('apiToken', apiTokenValue);
      newWindow.close();
      return true
    } else {
      alert('Ошибка аутентификации. Пожалуйста, проверьте введенный API ключ.');
      return false
    }
  });
}

const appendApiKeyButton = document.getElementById("appendApiKeyData");
appendApiKeyButton.addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    function: openWindow,
  });
});




// document.addEventListener('DOMContentLoaded', function() {
//   const progressBar = document.getElementById('file');
//   const collectDataButton = document.getElementById('collectData');

//   startTask();

//   function startTask() {
//       setInterval(function() {
//           chrome.storage.local.get('progress', function(data) {
//               let progress = data.progress;
//               updateProgressBar(progress);

//               if (progress < 100) {
//                   progressBar.style.display = 'block';
//                   collectDataButton.style.display = 'none';
//               } else {
//                   progressBar.style.display = 'none';
//                   collectDataButton.style.display = 'block';
//               }
//           });
//       }, 500);
//   }

//   function updateProgressBar(value) {
//       progressBar.value = value;
//       progressBar.textContent = value + '%';
//   }
// });

const progressBar = document.getElementById('file');
const collectDataButton = document.getElementById('collectData');

startTask();

function startTask() {
    setInterval(function() {
        chrome.storage.local.get('progress', function(data) {
            let progress = data.progress;
            updateProgressBar(progress);

            if (progress < 100) {
                progressBar.style.display = 'block';
                collectDataButton.style.display = 'none';
            } else {
                progressBar.style.display = 'none';
                collectDataButton.style.display = 'block';
            }
        });
    }, 500);
}

function updateProgressBar(value) {
    progressBar.value = value;
    progressBar.textContent = value + '%';
}